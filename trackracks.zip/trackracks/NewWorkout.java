import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class NewWorkout extends HttpServlet {
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
	
        String workoutDate = request.getParameter("workoutDate");
        String description = request.getParameter("description");
        String userID = request.getParameter("userID");
        try{
        
        //loading drivers for mysql
        Class.forName("com.mysql.jdbc.Driver");

	//creating connection with the database 
          Connection  con=DriverManager.getConnection("jdbc:mysql://localhost:3306/trackracks","root","1234");

        PreparedStatement ps=con.prepareStatement("insert into workout(userID,workoutDate,description) values(?,?,?)");
        ps.setString(1, userID);
        ps.setString(2, workoutDate);
        ps.setString(3, description);
        
        int i=ps.executeUpdate();
        
          if(i>0)
          {
            out.println("Workout added."+workoutDate);
          }
        
        }
        catch(Exception se)
        {
            se.printStackTrace();
        }
	
      }
    }
