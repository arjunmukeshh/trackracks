import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class Login extends HttpServlet{
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        try{
        
            //loading drivers for mysql
            Class.forName("com.mysql.jdbc.Driver");

            //creating connection with the database 
            Connection  con=DriverManager.getConnection("jdbc:mysql://localhost:3306/trackracks","root","1234");

            PreparedStatement ps=con.prepareStatement("select * from user where uname = '"+username+"' and upwd = '"+password+"'");
           //  ps.setString(1, username);
           // ps.setString(2, password);
            
            ResultSet rs = ps.executeQuery();
            if(!rs.next()) {
                out.println("<html>Login Failed.</html>");
            }
            else{
                request.getSession().setAttribute("username",username);
                response.sendRedirect("dashboard.jsp");
                out.println("<html> <h1> Welcome </h1> </html>");
            }
            
            
        }
        catch(SQLException se) {
            out.println(se.getMessage());
        } catch (ClassNotFoundException ce) {
            out.println(ce.getMessage());
        } catch (Exception ce) {
            out.println(ce.getMessage());
        }
	
    }
}
