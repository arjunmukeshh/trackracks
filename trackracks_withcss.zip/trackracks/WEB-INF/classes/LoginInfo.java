public enum LoginInfo {
    USER1("root", "admin");

    private final String username;
    private final String password;

    LoginInfo(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }
}